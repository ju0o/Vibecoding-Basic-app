## 한 줄 정의

환경변수(environment variable)는 **코드 바깥에서 프로그램에 값을 전달하는 설정 통로**입니다. Node.js에서 `process.env`가 ==사용자 환경을 담은 객체를 반환==하므로, `process.env.API_KEY`처럼 읽습니다. secret(비밀값)은 그중에서도 유출되면 안 되는 것 — API 키, DB 비밀번호, 토큰 — 이며, 이런 값은 **코드가 아니라 환경변수로** 관리해야 합니다.

이 원칙의 근거는 Twelve-Factor App입니다: ==설정을 환경변수에 저장하라==. 같은 코드가 개발·스테이징·운영에서 다른 값으로 돌아야 하므로, 달라지는 부분(설정)을 코드에서 빼내는 것입니다.

> [!KEY]
> 설정 분리가 제대로 됐는지 판단하는 한 줄 기준이 있습니다 — Twelve-Factor의 **리트머스 테스트**: "지금 이 저장소를 공개해도 자격 증명이 새지 않는가?" 통과하면 설정이 코드에서 잘 분리된 것이고, 실패하면(키가 코드에 박혀 있으면) 유출은 시간 문제입니다. 이 사이트도 비밀번호 해시를 `.env.local`(gitignore)에만 두어 이 테스트를 통과합니다.

![환경변수: 코드 바깥의 설정을 process.env로 주입, secret은 .gitignore로 격리](/lesson-diagrams/environment-variables-secrets/config-separation.svg)

## 왜 존재하는가

설정을 코드에 직접 쓰면 세 가지 문제가 생깁니다.

첫째, **배포 환경마다 값이 다릅니다.** 개발 DB와 운영 DB는 주소가 다르고, 테스트 API 키와 실제 API 키도 다릅니다. Twelve-Factor의 통찰은 "설정은 배포마다 크게 달라지지만 코드는 그렇지 않다"입니다 — 그러니 달라지는 것(설정)을 코드에서 분리해 주입해야 합니다.

둘째, **secret이 저장소에 영구히 남습니다.** API 키를 코드에 한 번 커밋하면, 나중에 지워도 Git 이력의 과거 커밋에 남습니다. 저장소에 접근할 수 있는 누구나(또는 실수로 공개되면 전 세계가) 그 키를 볼 수 있습니다. Git의 강점인 "모든 변경을 기록한다"가 secret에는 약점이 되는 셈입니다 — 앞서 Git 강의에서 배운 이력의 영속성이 여기서는 위험이 됩니다.

셋째, **코드에서 설정을 읽을 통로가 필요합니다.** 값을 바깥에 두더라도 프로그램이 그것을 읽어야 하고, Node.js는 `process.env`라는 표준 통로로 환경변수를 객체처럼 노출합니다.

## 작동 원리

### process.env로 읽기

Node.js에서 환경변수는 `process.env` 객체로 노출됩니다. 코드는 이렇게 읽습니다:

```javascript
const apiKey = process.env.API_KEY;
const dbUrl = process.env.DATABASE_URL;
```

값은 프로그램 바깥(셸, `.env` 파일, 배포 플랫폼 설정)에서 주입되고, 코드에는 "이름"만 남습니다. 같은 코드가 환경변수만 바꿔 개발·운영에서 다르게 동작합니다.

### 값은 언제나 문자열

중요한 함정 하나: ==환경변수는 근본적으로 문자열==입니다. Node.js 문서는 "Assigning a property on process.env will implicitly convert the value to a string"(값을 문자열로 암묵 변환)라고 명시합니다. 그래서 숫자나 불리언이 필요하면 코드에서 파싱해야 합니다:

```javascript
const port = Number(process.env.PORT);        // "3000" → 3000
const debug = process.env.DEBUG === "true";   // "true" → true
```

`process.env.PORT`를 숫자처럼 바로 쓰면 "3000" + 1이 "30001"이 되는 문자열 함정에 빠집니다.

### .env 파일과 .gitignore

로컬 개발에서는 값을 `.env` 파일에 모아두는 것이 편합니다. 하지만 이 파일에는 secret이 담기므로, ==반드시 `.gitignore`에 넣어 커밋에서 제외==합니다. 팀에는 값이 빈 `.env.example`만 공유해 "어떤 변수가 필요한지"를 알립니다.

> [!EXAMPLE]
> 이 사이트의 비밀번호 게이트가 정확히 이 패턴입니다. 비밀번호의 SHA-256 해시가 `.env.local`의 `NEXT_PUBLIC_SITE_PASSWORD_HASH`에 있고, 이 파일은 `.gitignore`에 있어 저장소에 커밋되지 않습니다. 코드(공개 저장소)에는 "해시를 환경변수에서 읽는다"는 로직만 있고 해시값 자체는 없습니다 — 리트머스 테스트를 통과하는 실제 예시입니다.

### 하드코딩에서 환경변수로 — 리팩터링

같은 코드가 어떻게 안전해지는지 봅시다. AI가 만든 흔한 형태:

```javascript
// 위험: 키가 코드에 박혀 커밋되면 이력에 영구히 남음
const client = new ApiClient("sk-live-abc123xyz");
```

이것을 환경변수로 분리합니다:

```javascript
// 안전: 코드에는 이름만, 값은 바깥에서 주입
const key = process.env.API_KEY;
if (!key) throw new Error("API_KEY 환경변수가 필요합니다");
const client = new ApiClient(key);
```

바뀐 것은 두 가지입니다 — 값이 코드 밖으로 나갔고, 없을 때 즉시 멈추는 검증이 붙었습니다. 이제 이 파일은 공개돼도 안전하며, 배포 환경마다 다른 키를 주입할 수 있습니다.

## 스펙과 세부

### process.env 사용 패턴

| 목적 | 코드 |
|---|---|
| 값 읽기 | `process.env.API_KEY` |
| 숫자 변환 | `Number(process.env.PORT)` |
| 불리언 변환 | `process.env.DEBUG === "true"` |
| 기본값 | `process.env.PORT ?? "3000"` |
| 필수 검증 | 없으면 시작 시 에러 던지기 |

### 무엇이 secret인가

| 설정 종류 | secret? | 처리 |
|---|---|---|
| API 키·토큰 | ✓ | 환경변수, 절대 커밋 금지 |
| DB 비밀번호·연결 문자열 | ✓ | 환경변수 |
| 포트·기능 플래그 | ✗ | 환경변수(설정이지만 비밀은 아님) |
| 공개 URL·앱 이름 | ✗ | 코드 상수도 가능 |

### .env 파일 관리

| 파일 | 커밋? | 용도 |
|---|---|---|
| `.env` / `.env.local` | ✗ (gitignore) | 실제 값(secret 포함) |
| `.env.example` | ✓ | 변수 이름만(값은 비움) |

### 상황별 빠른 참조

| 상황 | 처방 |
|---|---|
| API 키를 코드에 쓰고 싶다 | 환경변수로 분리(`process.env`) |
| 환경변수를 숫자로 쓰고 싶다 | `Number()`로 명시적 파싱 |
| `.env`를 만들었다 | `.gitignore`에 추가 확인 |
| 팀에 필요한 변수 알리기 | `.env.example`로 이름만 공유 |
| 실수로 secret을 커밋했다 | 이력에서 제거 + 키 즉시 회전(폐기·재발급) |

## 원문으로 읽기

> "The process.env property returns an object containing the user environment."
>
> — process.env 속성은 사용자 환경을 담은 객체를 반환한다.
> [Node.js process.env](https://nodejs.org/api/process.html)

환경변수가 코드에서 어떻게 보이는지를 정의합니다 — 특별한 API가 아니라 그냥 객체입니다. `process.env.NAME`으로 읽는 이 단순함이 환경변수를 "코드와 설정 사이의 표준 인터페이스"로 만듭니다.

> "Assigning a property on process.env will implicitly convert the value to a string."
>
> — process.env에 속성을 할당하면 값이 암묵적으로 문자열로 변환된다.
> [Node.js process.env](https://nodejs.org/api/process.html)

이 한 문장이 흔한 버그의 근원을 설명합니다. 환경변수는 모두 문자열이므로, `PORT=3000`을 읽으면 숫자 3000이 아니라 문자열 "3000"입니다. 숫자·불리언 비교 전에 반드시 변환해야 한다는 것을 기억해야 합니다.

> "An app's config is everything that is likely to vary between deploys."
>
> — 앱의 config는 배포마다 달라질 가능성이 있는 모든 것이다.
> [Twelve-Factor App: Config](https://12factor.net/config)

"무엇이 설정인가"에 대한 실용적 정의입니다. 판단 기준은 "배포마다 달라지는가"입니다 — DB 주소·API 키는 환경마다 다르니 설정이고, 앱의 이름·로직은 어디서나 같으니 코드입니다. 이 기준이 "무엇을 환경변수로 뺄지"를 정합니다.

> "Config varies substantially across deploys, code does not."
>
> — 설정은 배포마다 상당히 달라지지만, 코드는 그렇지 않다.
> [Twelve-Factor App: Config](https://12factor.net/config)

코드와 설정을 나누는 근본 이유입니다. 같은 코드가 여러 환경에서 돌아야 하므로, 달라지는 부분만 밖으로 빼면 코드는 하나로 유지되고 환경 전환은 값 교체만으로 끝납니다. "코드 하나, 설정 여럿"이 배포의 기본 구조입니다.

> "A litmus test for whether an app has all config correctly factored out of the code is whether the codebase could be made open source at any moment, without compromising any credentials."
>
> — 앱이 모든 설정을 코드에서 올바르게 분리했는지 판단하는 리트머스 테스트는, 어느 순간에든 자격 증명을 노출하지 않고 코드베이스를 오픈소스로 만들 수 있는가이다.
> [Twelve-Factor App: Config](https://12factor.net/config)

가장 실용적인 자가 점검 기준입니다. "지금 저장소를 공개해도 되는가?"를 물어, 안 된다면(키가 코드에 있다면) 아직 분리가 덜 된 것입니다. AI가 만든 코드를 검토할 때도 이 질문 하나면 충분합니다.

## 실전에서

### AI 코드의 하드코딩 잡아내기

AI에게 "이 API 연동해줘"라고 하면, 편의를 위해 API 키를 코드에 직접 박아 넣는 경우가 흔합니다 — 동작은 하니까요. 이것이 secret 유출의 첫 번째 경로입니다. AI 결과를 받으면 ==하드코딩된 키·토큰·비밀번호가 있는지==를 먼저 훑고, 발견하면 환경변수로 옮긴 뒤 `.env`를 `.gitignore`에 넣습니다. 리트머스 테스트("지금 공개해도 안전한가")가 이 검토의 기준입니다. 눈으로 찾기 어렵다면 `sk-`, `key`, `secret`, `password`, `token` 같은 문자열을 코드에서 검색해 보는 것이 빠른 1차 점검입니다 — 앞서 정규식·코드 검색 강의에서 익힌 기술이 여기서 보안 점검 도구가 됩니다.

### 실수로 커밋한 secret은 회전한다

secret을 실수로 커밋했다면, `.gitignore`에 추가하는 것만으로는 부족합니다 — 이미 Git 이력의 과거 커밋에 남아 있기 때문입니다. 이력에서 제거하는 것과 별개로, ==그 키를 폐기하고 새로 발급(회전)==해야 합니다. 한번 노출된 secret은 "노출됐다"고 가정하는 것이 안전합니다. 특히 저장소가 잠깐이라도 공개됐거나 CI 로그·포크에 복제됐다면, 그 키는 이미 수집됐다고 보고 회전이 유일한 확실한 대응입니다 — 봇이 공개 저장소의 키를 자동으로 긁어가는 것은 분 단위로 일어나는 현실입니다.

### 필수 환경변수는 시작할 때 검증

환경변수가 없으면 프로그램은 `undefined`로 조용히 잘못 동작하다가 엉뚱한 곳에서 터집니다. 예를 들어 `process.env.DATABASE_URL`이 없으면 DB 연결 코드가 `undefined`를 주소로 받아, 앱 시작은 성공했다가 첫 요청에서야 알 수 없는 에러로 실패합니다. 그래서 시작 시점에 "필수 변수가 다 있는가"를 검증해, 없으면 즉시 명확한 에러("DATABASE_URL이 필요합니다")로 멈추는 것이 좋습니다 — 늦게 터지는 모호한 버그보다 일찍 멈추는 명확한 에러가 낫습니다.

### 빌드 시점과 실행 시점의 환경변수

환경변수가 언제 읽히는지도 중요합니다. 일부 값은 빌드할 때 코드에 박히고(정적), 일부는 실행할 때 읽힙니다(동적). 특히 정적 빌드에서는 빌드 시점의 환경변수가 결과물에 고정되므로, 배포 후 값을 바꾸려면 다시 빌드해야 합니다. 이 사이트도 비밀번호 해시가 빌드 시점에 번들에 들어가므로, 비밀번호를 바꾸면 재빌드·재배포가 필요합니다 — 환경변수가 "언제" 주입되는지가 운영 방식을 좌우합니다.

> [!TIP]
> 새 secret이 필요할 때, ==먼저 `.env`에 넣고 `.gitignore`를 확인한 다음 코드를 작성==하는 순서를 습관화하세요. 코드에 값을 쓴 뒤 "나중에 환경변수로 빼야지" 하면, 그 사이에 커밋이 한 번이라도 일어나면 secret은 이미 이력에 남습니다. 순서가 곧 안전입니다.

## 한계와 트레이드오프

**환경변수는 문자열뿐입니다.** 구조화된 설정(중첩 객체, 배열)을 표현하기 어렵고, 모든 것이 문자열이라 파싱·검증 책임이 코드에 남습니다. 복잡한 설정은 환경변수로 "어떤 설정 파일을 쓸지"만 가리키고 실제 구조는 파일에 두는 절충도 씁니다.

**분리는 규율이지 자동이 아닙니다.** 환경변수 체계가 있어도, 개발자(또는 AI)가 편의를 위해 키를 코드에 박으면 무너집니다. 리트머스 테스트를 CI에서 자동 검사(secret 스캐너)로 강제하지 않으면, 결국 사람의 규율에 의존합니다. 특히 AI는 "동작하는 코드"를 목표로 하므로 키를 인라인으로 넣는 지름길을 택하기 쉽고, 그래서 이 분리 원칙은 AI 협업에서 사람이 지켜야 할 대표적 게이트가 됩니다.

**환경변수도 유출될 수 있습니다.** 코드에서 빼냈다고 끝이 아닙니다 — 환경변수를 로그에 출력하거나, 에러 메시지에 담거나, 클라이언트로 전송하면 다시 새어 나갑니다. 특히 이 사이트의 `NEXT_PUBLIC_` 접두사처럼 "클라이언트에 노출되는 환경변수"는 secret을 담으면 안 됩니다(그래서 이 사이트는 원본 비밀번호가 아니라 해시만 담습니다).

> [!WARNING]
> `NEXT_PUBLIC_` 같은 "클라이언트 노출" 접두사가 붙은 환경변수는 브라우저 번들에 그대로 들어갑니다 — 즉 전 세계가 볼 수 있습니다. 여기에는 진짜 secret(API 키·비밀번호 원문)을 절대 담으면 안 됩니다. 클라이언트에 필요한 값은 "노출돼도 안전한 것"(공개 키, 해시)만이어야 합니다. 접두사 하나가 "서버 전용"과 "전 세계 공개"를 가르므로, 환경변수에 이름을 붙일 때부터 그 변수가 어디까지 노출되는지를 의식해야 합니다.

## 더 읽기

- [Node.js process.env](https://nodejs.org/api/process.html) — 환경변수 읽기, 문자열 변환, 삭제
- [Twelve-Factor App: Config](https://12factor.net/config) — 설정 분리 원칙, 환경변수 저장, 리트머스 테스트

이전 순서: [인증, 세션, 토큰](/lessons/auth-session-token) — 여기서 다룬 토큰·세션 비밀키가 이 강의의 대표적 secret입니다. 이로써 data-backend 모듈이 "REST 설계 → DB → 인증 → 설정·secret"의 흐름으로 이어지며, 데이터가 오가는 경로와 그 경로를 지키는 방법을 함께 다루게 됩니다.
